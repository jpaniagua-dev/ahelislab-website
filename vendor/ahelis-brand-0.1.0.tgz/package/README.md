# @ahelis/brand

Rendu HTML natif et styles canoniques des sélecteurs de langue, bas de footer et
badges suisses Ahelis Lab. Aucun runtime Angular requis pour les sites statiques.
Les composants Angular de `@ahelis/ui` utilisent les mêmes feuilles de styles.

Exporter `renderLanguageSwitcher`, `renderFooterBottom` et `renderSwissBadge`
depuis `@ahelis/brand`. Les liens sont échappés et leurs protocoles vérifiés.
Charger les styles `@ahelis/brand/styles/language-switcher.css` et
`@ahelis/brand/styles/footer.css`. La langue, les destinations et le thème restent
explicites ; aucune préférence ni navigation n’est imposée par le paquet.

export type Language = 'fr' | 'en';
export type Theme = 'auto' | 'light' | 'dark';
export const languages: readonly Readonly<{ code: Language; label: string; tag: string }>[];
export function renderLanguageSwitcher(options: { value?: Language | ''; links: Record<Language, string>; label?: string; theme?: Theme; separator?: boolean }): string;
export function renderSwissBadge(options?: { locale?: Language; label?: string }): string;
export function renderFooterBottom(options?: { locale?: Language; theme?: Theme; year?: number; copyrightName?: string; privacyHref?: string; creditName?: string; creditHref?: string; swissLabel?: string }): string;
export const swissFlag: string;
export const heart: string;

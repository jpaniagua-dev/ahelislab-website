const escape = value => String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const safeHref = value => {
  const href = String(value);
  if (!['https:', 'http:'].includes(new URL(href, 'https://ahelislab.ch').protocol)) throw new Error('Unsupported component link protocol.');
  return escape(href);
};
const themeAttribute = theme => ['light', 'dark'].includes(theme) ? ` data-ah-theme="${theme}"` : '';
const logoNames = Object.freeze({ lab: 'Ahelis Lab', vault: 'Ahelis Vault', business: 'Ahelis Business' });

/** Render the approved complete logo or its mark, with the same CSS as Angular. */
export function renderLogo({ brand = 'lab', variant = 'full', theme = 'auto', label, decorative = false } = {}) {
  if (!Object.hasOwn(logoNames, brand) || !['full', 'mark'].includes(variant)) throw new Error('Unsupported logo brand or variant.');
  const wordmark = brand === 'lab' ? 'AHELIS LAB<span class="ah-logo__period">.</span>' : `Ahelis <strong>${brand === 'vault' ? 'Vault' : 'Business'}</strong>`;
  const accessibility = decorative ? ' aria-hidden="true"' : ` role="img" aria-label="${escape(label || logoNames[brand])}"`;
  return `<span class="ah-logo ah-logo--${brand}${variant === 'mark' ? ' ah-logo--mark' : ''}"${accessibility}${themeAttribute(theme)}><span class="ah-logo__mark" aria-hidden="true"></span>${variant === 'full' ? `<span class="ah-logo__wordmark" aria-hidden="true">${wordmark}</span>` : ''}</span>`;
}
export const languages = Object.freeze([
  Object.freeze({ code: 'fr', label: 'Français', tag: 'fr-CH' }),
  Object.freeze({ code: 'en', label: 'English', tag: 'en' }),
]);

/** Render real alternate-language links; applications use the Angular event adapter. */
export function renderLanguageSwitcher({ value = 'fr', links, label = 'Language', theme = 'auto', separator = false } = {}) {
  if (!links || languages.some(language => !links[language.code])) throw new Error('Provide a destination for every supported language.');
  return `<span class="language-switcher${separator ? ' language-switcher--separated' : ''}" role="group" aria-label="${escape(label)}"${themeAttribute(theme)}>${languages.map(language => `<a class="language-switcher__option" href="${safeHref(links[language.code])}" lang="${language.tag}" hreflang="${language.tag}" aria-label="${language.label}"${value === language.code ? ' aria-current="true"' : ''}>${language.code.toUpperCase()}</a>`).join('')}</span>`;
}

export const swissFlag = '<svg class="footer-swiss-flag" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><rect width="20" height="20" rx="3" fill="#da291c"/><path d="M8 4h4v4h4v4h-4v4H8v-4H4V8h4z" fill="#fff"/></svg>';
export const heart = '<svg class="footer-heart" width="14" height="14" viewBox="0 0 24 24" role="img" aria-label="love" focusable="false"><path fill="currentColor" d="M12 21s-9-5.6-9-12a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 6.4-9 12-9 12Z"/></svg>';

export function renderSwissBadge({ locale = 'fr', label } = {}) {
  return `<p class="footer-swiss">${swissFlag}<span>${escape(label ?? (locale === 'fr' ? 'Conçu, opéré et hébergé en Suisse' : 'Designed, operated and hosted in Switzerland'))}</span></p>`;
}

export function renderFooterBottom({ locale = 'fr', theme = 'auto', year = new Date().getFullYear(), copyrightName = 'Ahelis Lab', creditName = 'Ahelis Lab', creditHref = 'https://ahelislab.ch/', swissLabel } = {}) {
  return `<div class="footer-bottom" lang="${locale === 'fr' ? 'fr-CH' : 'en'}"${themeAttribute(theme)}>${renderSwissBadge({ locale, label: swissLabel })}<p class="footer-credit"><span>Made with</span>${heart}<span>by <a href="${safeHref(creditHref)}">${escape(creditName)}</a></span></p><p class="footer-legal">${escape(year)} ${escape(copyrightName)}</p></div>`;
}

# @ahelis/brand

Rendu HTML natif et styles canoniques des logos, sélecteurs de langue, bas de footer et
badges suisses Ahelis Lab. Aucun runtime Angular requis pour les sites statiques.
Les composants Angular de `@ahelis/ui` utilisent les mêmes feuilles de styles.

`renderLogo` accepte les options `brand` (`lab`, `vault`, `business`), `variant`
(`full`, `mark`), `theme` (`auto`, `light`, `dark`), `label` et `decorative`.
Le défaut est le logo complet du studio, nommé « Ahelis Lab » pour les lecteurs
d’écran. Les libellés personnalisés sont échappés. `decorative: true` masque le
logo lorsque le parent fournit déjà le nom accessible.

Charger `@ahelis/brand/styles/logos.css` avec un bundler CSS. Sans bundler, conserver
`styles/` et `logos/` côte à côte sur le serveur pour résoudre les images relatives.
Le paquet exporte aussi les [signes bruts](logos/README.md), utilisables comme favicons.

Exporter `renderLanguageSwitcher`, `renderFooterBottom` et `renderSwissBadge`
depuis `@ahelis/brand`. Les liens sont échappés et leurs protocoles vérifiés.
Charger les styles `@ahelis/brand/styles/language-switcher.css` et
`@ahelis/brand/styles/footer.css`. La langue, les destinations et le thème restent
explicites ; aucune préférence ni navigation n’est imposée par le paquet.

Le footer affiche le badge suisse à gauche et la signature au cœur rouge à droite,
sans année. Il ne rend aucun lien de confidentialité.
Il est réservé aux vitrines et pages sans sidebar. Les applications Angular avec
sidebar réutilisent `AhCreditComponent` dans le pied de celle-ci et chargent
`@ahelis/ui/styles/credit.css`. Règle canonique dans le `AGENTS.md` racine.

Le footer complet est rendu par `renderSiteFooter(options)` avec `navigation`,
`description`, `brandHref`, `brandLabel` et `callToAction` facultatif. Chaque groupe
de navigation contient `title`, `label` accessible facultatif et `links` (`label`,
`href`). Le contenu est échappé, les liens acceptent HTTP(S) ou un chemin relatif.
Charger aussi `styles/logos.css`, `styles/footer.css` et `styles/site-footer.css`.
Les options du bas de footer restent disponibles. Réserver ce footer aux vitrines
et pages sans sidebar. API complète et exemples dans le README racine du dépôt.

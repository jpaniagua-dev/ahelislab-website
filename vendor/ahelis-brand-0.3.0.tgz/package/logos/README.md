# Logos Ahelis

Signes validés le 2026-10-23, repris sans modification du dépôt
[`ahelislab-website`, commit `db63374`](https://github.com/jpaniagua-dev/ahelislab-website/commit/db6337494d21a8a5e5457294912cd33a043b1ac3).

| Fichier | Référence |
| --- | --- |
| `ahelis-lab.svg` | Favicon issu du `.brand-mark` de l’en-tête `ahelislab.ch` |
| `ahelis-vault.png` | Image originale `/vault/app-icon.png` de `vault.ahelislab.ch` |
| `ahelis-business.svg` | Image originale `/business/app-icon.svg` de `business.ahelislab.ch` |

Les logos complets sont rendus par `AhLogoComponent` ou `renderLogo` avec les
proportions, typographies, espacements et couleurs de leurs en-têtes respectifs.
Le signe du studio est un anneau jaune et son satellite. Sa planète illustrative
reste un autre élément visuel. Les mots « Vault » et « Business » restent jaunes.

Ces fichiers sont aussi exportés par les deux paquets pour les favicons et autres
usages nécessitant une image. Une application copie le fichier choisi dans ses
assets publics et renseigne son URL locale dans `<link rel="icon">`.

Les CSS de référence vivent dans `packages/brand/styles/logos.css`. Le build prépare
leurs copies et ces images dans le paquet Angular, sans seconde source maintenue.

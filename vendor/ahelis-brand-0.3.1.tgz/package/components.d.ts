export type Language = 'fr' | 'en';
export type Theme = 'auto' | 'light' | 'dark';
export type LogoBrand = 'lab' | 'vault' | 'business';
export type LogoVariant = 'full' | 'mark';
export function renderLogo(options?: { brand?: LogoBrand; variant?: LogoVariant; theme?: Theme; label?: string; decorative?: boolean }): string;
export const languages: readonly Readonly<{ code: Language; label: string; tag: string }>[];
export function renderLanguageSwitcher(options: { value?: Language | ''; links: Record<Language, string>; label?: string; theme?: Theme; separator?: boolean }): string;
export function renderSwissBadge(options?: { locale?: Language; label?: string }): string;
export function renderFooterBottom(options?: { locale?: Language; theme?: Theme; /** @deprecated No year is rendered. */ year?: number; /** @deprecated No copyright line is rendered. */ copyrightName?: string; /** @deprecated Privacy links are rendered by the consuming page. */ privacyHref?: string; creditName?: string; creditHref?: string; swissLabel?: string }): string;
export const swissFlag: string;
export const heart: string;

export interface FooterLink { readonly label: string; readonly href: string; }
export interface FooterNav { readonly title: string; readonly label?: string; readonly links: readonly FooterLink[]; }
export interface SiteFooterOptions {
  navigation?: readonly FooterNav[];
  description?: readonly string[];
  brandHref?: string;
  brandLabel?: string;
  callToAction?: FooterLink;
  locale?: Language;
  theme?: Theme;
  /** @deprecated No year is rendered. */ year?: number;
  /** @deprecated No copyright line is rendered. */ copyrightName?: string;
  creditName?: string;
  creditHref?: string;
  swissLabel?: string;
}
export function renderSiteFooter(options?: SiteFooterOptions): string;
